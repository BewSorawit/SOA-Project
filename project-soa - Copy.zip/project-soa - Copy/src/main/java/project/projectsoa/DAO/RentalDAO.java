package project.projectsoa.DAO;

import java.util.ArrayList;
import project.projectsoa.model.*;
import org.hibernate.Session;
import org.hibernate.query.Query;

public class RentalDAO {
	
	

}
