package com.SOAproject.projectsoa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSoaApplicationTests {

	@Test
	void contextLoads() {
	}

}
