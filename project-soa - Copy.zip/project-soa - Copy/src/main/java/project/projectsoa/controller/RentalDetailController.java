package project.projectsoa.controller;

import java.util.List;
import project.projectsoa.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import project.projectsoa.repository.*;

import project.projectsoa.model.Rental;

@RestController
@RequestMapping("/api/rentaldetail")
public class RentalDetailController {
	
	@Autowired
	private RentalDetailRepository rentalDetailRepository;
	
	@PostMapping("/addDetail")
	RentalDetail newRentalDetail(@RequestBody RentalDetail newRentalDetail) {
		return rentalDetailRepository.save(newRentalDetail);
	}
	@GetMapping("/getAll")
	List<RentalDetail> getAllRentalDetail(){
		return rentalDetailRepository.findAll();
	}

}
