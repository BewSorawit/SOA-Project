package project.projectsoa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import project.projectsoa.model.*;

public interface RentalDetailRepository extends JpaRepository<RentalDetail,Integer> {


}
